exports.sendOtpOnPhone = async () => {
    console.log("OTP SENT SUCCESSFULLY.");
    return true;
}